const app = angular.module("myApp", ['ngRoute']);
const urlAPI = "https://623446e86d5465eaa5171b85.mockapi.io/account";
app.config(function ($routeProvider) {
    $routeProvider
        .when('/', { templateUrl: 'pages/home.html' })
        .when('/ask', { templateUrl: 'pages/ask.html' })
        .when('/about', { templateUrl: 'pages/about.html' })
        .when('/contact', { templateUrl: 'pages/contact.html' })
        .when('/feedback', { templateUrl: 'pages/feedback.html' })
        .when("/qlmh", { templateUrl: "pages/qlMonHoc.html" })
        .when("/qltk", { templateUrl: "pages/qlTaiKhoan.html" })
        .when('/courses', { templateUrl: 'pages/courses.html', controller: 'mySubject' })
        .when('/quiz/:id/:name', { templateUrl: 'pages/quiz.html', controller: 'quizsCtrl' })
});

// Tài khoản
app.controller("myProfile", function ($scope, $http, $rootScope) {
    $scope.dangKy = {};
    $scope.mkMoi = {};
    $scope.doiMatKhau = {};
    $scope.login = {};
    $scope.profile = {};
    $rootScope.users = [];
    $rootScope.user;
    $rootScope.tenNguoiDung;
    $rootScope.permission;
    $http.get(urlAPI).then(function (reponse) {
        $rootScope.users = reponse.data;
    });

    $scope.login = function () {
        var flag = false;
        for (let i = 0; i < $rootScope.users.length; i++) {
            if (
                $rootScope.users[i].username == $scope.login.username &&
                $rootScope.users[i].password == $scope.login.password
            ) {
                flag = true;
                $rootScope.user = $rootScope.users[i].username;
                $rootScope.tenNguoiDung = $rootScope.users[i].fullname;
                if ($rootScope.users[i].permission == "admin") {
                    $rootScope.permission = $rootScope.users[i].permission;
                }
            }
        }
        if (flag) {
            $rootScope.flag = true;
            localStorage.setItem("fullname", $rootScope.tenNguoiDung);
            localStorage.setItem("user", JSON.stringify($rootScope.users));
            Swal.fire({
                icon: "success",
                title: "Đăng nhập thành công",
                text: "Chuyển hướng đến trang chủ!",
                showConfirmButton: false,
                timer: 1000,
            });
            $('#dangNhap').modal('hide');
            window.location.href = "#/";
        } else {
            $rootScope.flag = false;
            Swal.fire({
                icon: "error",
                title: "Đăng nhập thất bại",
                text: "Mật khẩu không chính xác!",
            });
        }
    };

    $scope.signUp = function () {
        $scope.flag = false;
        $scope.password2;
        if ($scope.dangKy.password == $scope.password2) {
            $scope.flag = true;
            $http.post(urlAPI, $scope.dangKy).then(function (response) {
                $scope.users.push(response.data);
            });
        }
        if ($scope.flag) {
            Swal.fire({
                icon: "success",
                title: "Đăng ký thành công",
                text: "Chuyển hướng đến trang chủ!",
                showConfirmButton: false,
                timer: 1000,
            });
            $('#dangKy').modal('hide');
            window.location.href = "#/";
        } else {
            Swal.fire({
                icon: "error",
                title: "Đăng ký thất bại",
                text: "Mật khẩu không chính xác!",
            });
        }
    };

    $scope.quenMatKhau = function () {
        $scope.index = 0;
        $scope.flag = 0;
        for (var i = 0; i < $scope.users.length; i++) {
            if ($scope.email == $scope.users[i].email) {
                $scope.flag++;
                $scope.index = i;
            }
        }
        $scope.flag == 1 ? alert("Mật khẩu của bạn là: " + $scope.users[$scope.index].password) : alert("Nhập sai email!");
    };

    $scope.doiMatKhau = function () {
        for (let i = 0; i < $rootScope.users.length; i++) {
            const urlId = urlAPI + "/" + i;
            $rootScope.user = $rootScope.users[i].username;
            if (
                $rootScope.users[i].username == $rootScope.user &&
                $rootScope.users[i].password == $scope.doiMatKhau.password1 &&
                $scope.doiMatKhau.password2 == $scope.mkMoi.password
            ) {
                $http.put(urlId, $scope.mkMoi).then(function (response) {
                    Swal.fire({
                        icon: "success",
                        title: "Đổi mật khẩu thành công!",
                        text: "Chuyển hướng đến trang chủ!",
                        showConfirmButton: false,
                        timer: 1000,
                    });
                    $('#doiMatKhau').modal('hide');
                    window.location.href = "#/";
                });
                return;
            } else if ($scope.doiMatKhau.password2 != $scope.mkMoi.password) {
                Swal.fire({
                    icon: "error",
                    title: "Mật khẩu mới không khớp nhau!",
                });
            } else if ($rootScope.users[i].password != $scope.doiMatKhau.password1) {
                Swal.fire({
                    icon: "error",
                    title: "Mật khẩu cũ không đúng!",
                });
            }
        }
    };

    $scope.updateProfile = function () {
        for (let i = 0; i < $rootScope.users.length; i++) {
            const urlId = urlAPI + "/" + i;
            if ($rootScope.user == $rootScope.users[i].username) {
                $http.put(urlId, $scope.profile);
                Swal.fire({
                    icon: "success",
                    title: "Cập nhật thông tin thành công!",
                    text: "Chuyển hướng đến trang chủ!",
                    showConfirmButton: false,
                    timer: 1000,
                });
                $('#updateProfile').modal('hide');
                window.location.href = "#/";
                return;
            }
        }
    };

    $scope.dangXuat = function () {
        $rootScope.user = null;
        localStorage.clear();
        window.location.reload();
        Swal.fire({
            icon: "success",
            title: "Đăng xuất thành công!",
            text: "Chuyển hướng đến trang chủ!",
            showConfirmButton: false,
            timer: 1000,
        });
    };
});

// Danh sách bài quiz
app.controller("quizsCtrl", function ($http, $routeParams, quizFactory) {
    $http.get("js/db/Quizs/" + $routeParams.id + ".js").then(function (reponse) {
        quizFactory.questions = reponse.data;
    });
});

// Quản lý môn học
app.controller('mySubject', function ($scope, $http, $rootScope) {
    $scope.listSubject = [];
    $scope.monHoc;
    $scope.index = -1;
    $scope.pageSize = 3;
    $scope.start = 0;
    $http.get("js/db/Subjects.js").then(function (res) {
        $scope.listSubject = res.data;
    });

    $scope.edit = function (index) {
        $scope.index = index;
        $scope.monHoc = angular.copy($rootScope.listSubject[index]);
    };

    $scope.add = function () {
        $rootScope.listSubject.push(angular.copy($scope.monHoc));
        $scope.refesh();
    };
    $scope.update = function () {
        $rootScope.listSubject[$scope.index] = $scope.monHoc;
    };
    $scope.delete = function (index) {
        $rootScope.listSubject.splice(index, 1);
        $scope.refesh();
    };
    $scope.refesh = function () {
        $scope.monHoc = {};
        $scope.index = -1;
    };

    $scope.prev = function () {
        if ($scope.start > 0) {
            $scope.start -= $scope.pageSize;
        }
    }
    $scope.next = function () {
        if ($scope.start < $scope.listSubject.length - $scope.pageSize) {
            $scope.start += $scope.pageSize;
        }
    }
});

// Quản lý tài khoản
app.controller("myAccount", function ($scope, $rootScope, $http) {
    $scope.taiKhoan;
    $scope.edit = function (index) {
        $scope.index = index;
        $scope.taiKhoan = angular.copy($rootScope.users[index]);
    };

    $scope.add = function () {
        $http.post(urlAPI, $scope.taiKhoan).then(function (response) {
            $scope.users.push(response.data);
            $scope.refeshTaiKhoan();
            Swal.fire({
                icon: "success",
                title: "Thêm thành công!",
                showConfirmButton: false,
                timer: 1000,
            });
        });
    };
    $scope.update = function () {
        for (let i = 0; i < $rootScope.users.length; i++) {
            const urliD = urlAPI + "/" + i;
            if ($rootScope.users[i].username == $scope.taiKhoan.username) {
                $http.put(urliD, $scope.taiKhoan).then(function (response) {
                    $scope.refesh();
                    Swal.fire({
                        icon: "success",
                        title: "Cập nhật thành công!",
                        showConfirmButton: false,
                        timer: 1000,
                    });
                });
            }
        }
    };
    $scope.delete = function (index) {
        const id = $rootScope.users[index].id;
        const apiDelete = urlAPI + "/" + id;
        $http.delete(apiDelete).then(function (response) {
            $rootScope.users.splice(index, 1);
            Swal.fire({
                icon: "success",
                title: "Xoá thành công!",
                showConfirmButton: false,
                timer: 1000,
            });
            $scope.refesh();
        });
    };
    $scope.refesh = function () {
        $scope.taiKhoan = {};
        $scope.index = -1;
    };
});

// Quiz
app.directive("quizfpoly", function (quizFactory, $routeParams) {
    return {
        restrict: "AE",
        $scope: {},
        templateUrl: 'pages/template-quiz.html',
        link: function ($scope) {
            $scope.subjectName = $routeParams.name;
            $scope.start = function () {
                $scope.id = 1;
                $scope.quizOver = false; //chua hoan thanh
                $scope.inProgess = true;
                $scope.getQuestion();
            };
            $scope.reset = function () {
                $scope.inProgess = false;
                $scope.score = 0;
            };
            $scope.getQuestion = function () {
                var quiz = quizFactory.getQuestion($scope.id);
                if (quiz) {
                    $scope.question = quiz.Text;
                    $scope.options = quiz.Answers;
                    $scope.answer = quiz.AnswerId;
                    $scope.answerMode = true;
                } else {
                    $scope.quizOver = true;
                }
            }
            $scope.checkAnswer = function () {
                if (!$('input[name="answer"]:checked').length) return;
                var ans = $('input[name="answer"]:checked').val();
                if (ans == $scope.answer) {
                    $scope.score++;
                    $scope.correctAns = true;
                } else {
                    $scope.correctAns = false;
                }
                $scope.answerMode = false;
            };
            $scope.nextQuestion = function () {
                $scope.id++;
                $scope.getQuestion();
            }
            $scope.reset();
        }
    }
});

// Câu hỏi và trả lời
app.factory('quizFactory', function ($http, $routeParams) {
    $http.get("js/db/Quizs/" + $routeParams.id + ".js")
        .then(function (reponse) {
            questions = reponse.data;
        });
    return {
        getQuestion: function (id) {
            var randomItem = questions[Math.floor(Math.random() * questions.length)];
            var count = questions.length;
            if (count > 10) {
                count = 10;
            }
            if (id < count) {
                return randomItem;
            } else {
                return false;
            }
        },
    };
});

// Bộ đếm thời gian 10 phút
app.controller('myCtrl', function ($scope, $interval) {
    $scope.time = new Date();
    $scope.minitues = 10;
    $scope.seconds = 01;
    $interval(function () {
        $scope.time = new Date();
        if ($scope.seconds <= 0) {
            $scope.seconds = 59;
            $scope.minitues--;
        } else {
            $scope.seconds--;
        }
    }, 1000);
});