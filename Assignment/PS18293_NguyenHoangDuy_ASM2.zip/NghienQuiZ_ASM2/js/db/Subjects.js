[
    {
        "Id": "ADAV",
        "Name": "Lập trình Android nâng cao",
        "Logo": "ADAV.jpg"
    },
    {
        "Id": "ADBS",
        "Name": "Lập trình Android cơ bản",
        "Logo": "ADBS.jpg"
    },
    {
        "Id": "ADTE",
        "Name": "Kiểm thử ứng dụng Android",
        "Logo": "ADTE.jpg"
    },
    {
        "Id": "ADUI",
        "Name": "Thiết kế UI trên Android",
        "Logo": "ADUI.jpg"
    },
    {
        "Id": "ASNE",
        "Name": "Lập trình ASP.NET",
        "Logo": "ASNE.jpg"
    },
    {
        "Id": "CLCO",
        "Name": "Điện toán đám mây",
        "Logo": "CLCO.jpg"
    },
    {
        "Id": "DBAV",
        "Name": "SQL Server",
        "Logo": "DBAV.jpg"
    },
    {
        "Id": "DBBS",
        "Name": "Cơ sở dữ liệu",
        "Logo": "DBBS.jpg"
    },
    {
        "Id": "GAME",
        "Name": "Lập trình game 2D",
        "Logo": "GAME.jpg"
    },
    {
        "Id": "HTCS",
        "Name": "HTML5 và CSS3",
        "Logo": "HTCS.jpg"
    },
    {
        "Id": "INMA",
        "Name": "Internet Marketing",
        "Logo": "INMA.jpg"
    },
    {
        "Id": "JAAV",
        "Name": "Lập trình Java nâng cao",
        "Logo": "JAAV.jpg"
    },
    {
        "Id": "JABS",
        "Name": "Lập trình OOP với Java",
        "Logo": "JABS.jpg"
    },
    {
        "Id": "JSPR",
        "Name": "Lập trình JavaScript",
        "Logo": "JSPR.jpg"
    },
    {
        "Id": "LAYO",
        "Name": "Thiết kế layout",
        "Logo": "LAYO.jpg"
    },
    {
        "Id": "MOWE",
        "Name": "Thiết kế web cho di động",
        "Logo": "MOWE.jpg"
    },
    {
        "Id": "PHPP",
        "Name": "Lập trình PHP",
        "Logo": "PHPP.jpg"
    },
    {
        "Id": "PMAG",
        "Name": "Quản lý dự án với Agile",
        "Logo": "PMAG.jpg"
    },
    {
        "Id": "VBPR",
        "Name": "Lập trình VB.NET",
        "Logo": "VBPR.jpg"
    },
    {
        "Id": "WEBU",
        "Name": "Xây dựng trang web",
        "Logo": "WEBU.jpg"
    }
]